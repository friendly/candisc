## MorphoTools2 1.0.1.0


* Linear discriminant analysis computes coefficients of the linear discriminant functions.


## MorphoTools2 1.0.0.0

* First public release.
