#' 25 morphological characters of three species of the \emph{Centaurea phrygia} complex
"centaurea"

