library(testthat)
library(MorphoTools2)
#library(visualTest)
#library(png)

test_check("MorphoTools2")

