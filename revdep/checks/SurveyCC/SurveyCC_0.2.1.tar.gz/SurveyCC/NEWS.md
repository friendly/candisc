# SurveyCC 0.2.1

* Added a `NEWS.md` file to track changes to the package.

* This is a resubmission (2024-07-05): made changes requested from R Journal reviewers. The main change is that the output of the main outfacing function (`surveycc`) has a class, and this class now has an S3 plotting method. There were other small changes such as removing commented-out code blocks, changing instances of "1:length()" to "seq_along()", etc. Also, the project is now connected to git/github.